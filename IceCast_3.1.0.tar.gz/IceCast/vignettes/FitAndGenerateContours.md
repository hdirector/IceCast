---
title: "Fitting and Generating Contour Forecasts"
author: "Hannah M. Director, Adrian E. Raftery, and Cecilia M. Bitz"
output: rmarkdown::html_vignette
vignette: >
  %\VignetteEngine{knitr::rmarkdown}
  %\VignetteIndexEntry{Fitting and Generating Contour Forecasts}
  %\VignetteEncoding{UTF-8}
---



## Introduction
This vignette introduces how to fit and generate sea ice edge contours using the
methods proposed in *Probabilistic Forecasting of the Arctic Sea Ice Edge with Contour Modeling* (Director et al. 2020).  This vignette explains how 
to fit and generate contours models with the *IceCast* R package. These forecasts
are used as a component in Mixture Contour Forecasts. To ensure fast loading many 
values are pre-loaded or only run for a short time. More realistic scripts without these simplifications can be found at https://github.com/hdirector/ProbSeaIce. 

In this vignette, we will issue a forecast for September 2008 at a 1.5-month lead
time. We will use the 25-member ensemble from the European Centre for Medium-Range Weather
Forecasts (ECMWF).  We have converted the data to a Polar stereographic grid. 
We will refer to this as the ECMWF forecast. This model output is available from the
Copernicus Climate Change Service (2019) and the Sea Ice Prediction Network 
Predictability Portal. We will also use observations of the monthly sea ice 
concentration obtained from the National Aeronautics and Space Administration 
(NASA) satellites Nimbus-7 SMMR and DMSP SSM/I-SSMIS  and processed by the 
bootstrap algorithm. These data are distributed by the National Snow and Ice Data
Center (NSIDC) (Comiso 2017).

## Setting up
To fit and generate contours, we use the *IceCast* R package. We'll also load the 
*viridis* (Garnier et al. 2017) and *fields* (Nychka et al. 2017) R packages
for visualization.

```r
library("IceCast")
library("viridis")
library("fields")
```

We also need to specify what month we are interested in forecasting, the 
start and end years of the training period, the level of minimum sea ice concentration 
to be counted as containing sea ice, and what year to start fitting the bias 
correction. This last variable usually corresponds to the earliest year with data 
available for both observations and predictions.

```r
month <- 9
train_start_year <- 1993
train_end_year <- 2007
level <- 15
train_bc_start_year <- 1993
```

We also need variables defining how to run the Markov chain Monte Carlo (MCMC) 
algorithm. This vignette is just for demonstrating how to use the code, so we 
will choose an extremely low number of iterations. This is *NOT* enough iterations
to use for valid inference. See the supplemental materials in Director et al. (2020)
for information on determining appropriate chain lengths and burn-in.

```r
n_iter <- 100
burn_in <- 10
```


## Fitting the Contour with MCMC
As a first step for fitting, we load and format the bootstrap sea ice 
concentration from the binary files. We can load the data as follows where
`obs_file_path` refers to a file path for a folder containing observed bootstrap sea 
ice concentration data. The observed files must be named using the original 
file names used by NSIDC (i.e. `bt_198301_n07_v02_n.bin`). For use with this vignette, 
the resulting `obs` object is stored in the package.

```r
##Not run##
# obs_file_path <- 'path_to_observation_data'
# bs_version <- 3.1
# dat_type_obs <- "bootstrap"
# obs <- read_monthly_BS(start_year = train_bc_start_year, end_year = train_end_year,
#                        version = bs_version, file_folder = obs_file_path)
```


Once we have the observations, we compute the set of lengths describing
how far the ice extends in various directions.
For more detail on how to compute this step, see the section *Computing Line Lengths* in
the *Contour-Shifting with the IceCast Package* vignette. This computation takes a few minutes,
so the resulting `y_train` object has been loaded in the package for use with this vignette.

```r
# ## Not run ##
# y_train <- find_y(start_year = train_start_year, end_year = train_end_year,
#                   obs_start_year = train_start_year,
#                   pred_start_year = NULL, observed = obs[train_ind, month,,],
#                   predicted = NULL, reg_info, month, level,
#                   dat_type_obs, dat_type_pred, obs_only = TRUE)
```


We do not fit regions that are completely ice-covered or
completely ice-free for all years in the training period.  In such cases, our 
forecast is simply that the region is completely ice-covered or ice free respectively. 
We use the $y$ values in the training period, `y_train$obs`, 
to determine which regions need to be fit. We also create a `SpatialPolygons` 
object of all fully ice-covered regions that will be included in every generated
contour.


```r
temp <- to_fit(y_train$obs, reg_info)
regs_to_fit <- temp$regs_to_fit
full <- temp$full
```

The y-values are then converted to proportions. 

```r
prop_train <- y_to_prop(y = y_train$obs, regs_to_fit, reg_info)
prop_train <- lapply(prop_train, function(y){sapply(y, function(x){x})})
```

These proportions are transformed to cover the full real line typically with the
logit function. If the proportion is greater than 
$1-\epsilon$ or less than $\epsilon$ for a small $\epsilon$, then the $logit(1 - \epsilon)$ or the
$logit(\epsilon)$ is used instead.

```r
eps <- .01
prop_train_tilde <- list()
for (r in regs_to_fit) {
  ub_ind <- which(prop_train[[r]] >= 1 - eps)
  prop_train[[r]][ub_ind] <- 1 - eps
  lb_ind <- which(prop_train[[r]] <= eps)
  prop_train[[r]][lb_ind] <- eps
  prop_train_tilde[[r]] <- logit(prop_train[[r]])
}
```

Priors need to specified for the transformed means, $\mu$. Typically, these priors 
will be based on the  bias-corrected ensemble. See the vignette 
*Contour-Shifting with the IceCast Package* or Director et al. (2020) for more
information on bias-correction of an ensemble. Here, we simply load 
priors that have been previously computed.

```r
data(prop_bc)
```

We also load the prior bounds for $\sigma$

```r
data("ub_props")
data("lb_props")
```

Now, we can fit the contour model.  We run the Markov chain Monte Carlo (MCMC)
algorithm for all regions. We loop over each region and sample the chains 
individually. Remember that the 500 iterations used here is too low for valid inference,
we are merely demonstrating how the code works in this vignette.

```r
res_short <- list()
for (r in regs_to_fit) {
  res_short[[r]] <- fit_cont_pars(r = r, n_iter = n_iter,
                                  prop_tilde = prop_train_tilde[[r]],
                                  reg_info = reg_info, prop0 = prop_bc[[r]],
                                  ub_prop = ub_props[r], lb_prop = lb_props[r])
}
```


With the MCMC complete, we can compute the parameters $\mu$ and $\Sigma$
for each region. All parameters values are stored in a single list called `pars`.


```r
pars <- list()
for (r in regs_to_fit) {
  pars[[r]] <- calc_pars(res_r = res_short[[r]], burn_in, r = r)
}
```
The previous step completed the model fitting, so we now have a full model for generating contours.
We generate 5 contours here to illustrate how the code works for generating contours.
In practice, substantially more contours should be drawn. Initially 
contours are generated for each region separately


```r
indiv_conts <- list()
n_gen <- 5
for (r in regs_to_fit) {
  indiv_conts[[r]] <- gen_cont(r, pars_r = pars[[r]], reg_info, n_gen,
                               rand = res_short[[r]]$rand, start = res_short[[r]]$start,
                               start_inds = res_short[[r]]$start_inds,
                               end = res_short[[r]]$end, end_inds = res_short[[r]]$end_inds)
 }
```

```
## [1] "WARNING: Geosphere Package is not installed. Planar areas,\n          not geodetic areas were calculated. For geodetic areas,\n          install Geosphere package and re-run get_area"
## [1] "WARNING: Geosphere Package is not installed. Planar areas,\n          not geodetic areas were calculated. For geodetic areas,\n          install Geosphere package and re-run get_area"
## [1] "WARNING: Geosphere Package is not installed. Planar areas,\n          not geodetic areas were calculated. For geodetic areas,\n          install Geosphere package and re-run get_area"
## [1] "WARNING: Geosphere Package is not installed. Planar areas,\n          not geodetic areas were calculated. For geodetic areas,\n          install Geosphere package and re-run get_area"
```


Then the contours from different regions are merged together.

```r
conts <- merge_conts(conts = indiv_conts, full = full)
```

Let's plot a few contours to view

```r
par(mfrow = c(2, 2), oma = rep(0, 4), mar = rep(0, 4))
for (i in 1:4) {
 plot(land, col = 'grey')
 plot(conts[[i]], add = T, col = 'blue')
}
```

![plot of chunk plot sample contours](figure/plot sample contours-1.png)

Finally, we can estimate the probability of sea ice presence. This estimate
is based on the proportion of generated contours that enclose each grid box. 

```r
cont_prob <- prob_map(merged = conts)
```

```
## [1] "WARNING: Geosphere Package is not installed. Planar areas,\n          not geodetic areas were calculated. For geodetic areas,\n          install Geosphere package and re-run get_area"
## [1] "WARNING: Geosphere Package is not installed. Planar areas,\n          not geodetic areas were calculated. For geodetic areas,\n          install Geosphere package and re-run get_area"
## [1] "WARNING: Geosphere Package is not installed. Planar areas,\n          not geodetic areas were calculated. For geodetic areas,\n          install Geosphere package and re-run get_area"
## [1] "WARNING: Geosphere Package is not installed. Planar areas,\n          not geodetic areas were calculated. For geodetic areas,\n          install Geosphere package and re-run get_area"
## [1] "WARNING: Geosphere Package is not installed. Planar areas,\n          not geodetic areas were calculated. For geodetic areas,\n          install Geosphere package and re-run get_area"
## [1] "WARNING: Geosphere Package is not installed. Planar areas,\n          not geodetic areas were calculated. For geodetic areas,\n          install Geosphere package and re-run get_area"
## [1] "WARNING: Geosphere Package is not installed. Planar areas,\n          not geodetic areas were calculated. For geodetic areas,\n          install Geosphere package and re-run get_area"
## [1] "WARNING: Geosphere Package is not installed. Planar areas,\n          not geodetic areas were calculated. For geodetic areas,\n          install Geosphere package and re-run get_area"
## [1] "WARNING: Geosphere Package is not installed. Planar areas,\n          not geodetic areas were calculated. For geodetic areas,\n          install Geosphere package and re-run get_area"
## [1] "WARNING: Geosphere Package is not installed. Planar areas,\n          not geodetic areas were calculated. For geodetic areas,\n          install Geosphere package and re-run get_area"
## [1] "WARNING: Geosphere Package is not installed. Planar areas,\n          not geodetic areas were calculated. For geodetic areas,\n          install Geosphere package and re-run get_area"
## [1] "WARNING: Geosphere Package is not installed. Planar areas,\n          not geodetic areas were calculated. For geodetic areas,\n          install Geosphere package and re-run get_area"
## [1] "WARNING: Geosphere Package is not installed. Planar areas,\n          not geodetic areas were calculated. For geodetic areas,\n          install Geosphere package and re-run get_area"
## [1] "WARNING: Geosphere Package is not installed. Planar areas,\n          not geodetic areas were calculated. For geodetic areas,\n          install Geosphere package and re-run get_area"
## [1] "WARNING: Geosphere Package is not installed. Planar areas,\n          not geodetic areas were calculated. For geodetic areas,\n          install Geosphere package and re-run get_area"
## [1] "WARNING: Geosphere Package is not installed. Planar areas,\n          not geodetic areas were calculated. For geodetic areas,\n          install Geosphere package and re-run get_area"
## [1] "WARNING: Geosphere Package is not installed. Planar areas,\n          not geodetic areas were calculated. For geodetic areas,\n          install Geosphere package and re-run get_area"
## [1] "WARNING: Geosphere Package is not installed. Planar areas,\n          not geodetic areas were calculated. For geodetic areas,\n          install Geosphere package and re-run get_area"
## [1] "WARNING: Geosphere Package is not installed. Planar areas,\n          not geodetic areas were calculated. For geodetic areas,\n          install Geosphere package and re-run get_area"
## [1] "WARNING: Geosphere Package is not installed. Planar areas,\n          not geodetic areas were calculated. For geodetic areas,\n          install Geosphere package and re-run get_area"
## [1] "WARNING: Geosphere Package is not installed. Planar areas,\n          not geodetic areas were calculated. For geodetic areas,\n          install Geosphere package and re-run get_area"
## [1] "WARNING: Geosphere Package is not installed. Planar areas,\n          not geodetic areas were calculated. For geodetic areas,\n          install Geosphere package and re-run get_area"
## [1] "WARNING: Geosphere Package is not installed. Planar areas,\n          not geodetic areas were calculated. For geodetic areas,\n          install Geosphere package and re-run get_area"
## [1] "WARNING: Geosphere Package is not installed. Planar areas,\n          not geodetic areas were calculated. For geodetic areas,\n          install Geosphere package and re-run get_area"
## [1] "WARNING: Geosphere Package is not installed. Planar areas,\n          not geodetic areas were calculated. For geodetic areas,\n          install Geosphere package and re-run get_area"
## [1] "WARNING: Geosphere Package is not installed. Planar areas,\n          not geodetic areas were calculated. For geodetic areas,\n          install Geosphere package and re-run get_area"
## [1] "WARNING: Geosphere Package is not installed. Planar areas,\n          not geodetic areas were calculated. For geodetic areas,\n          install Geosphere package and re-run get_area"
## [1] "WARNING: Geosphere Package is not installed. Planar areas,\n          not geodetic areas were calculated. For geodetic areas,\n          install Geosphere package and re-run get_area"
## [1] "WARNING: Geosphere Package is not installed. Planar areas,\n          not geodetic areas were calculated. For geodetic areas,\n          install Geosphere package and re-run get_area"
## [1] "WARNING: Geosphere Package is not installed. Planar areas,\n          not geodetic areas were calculated. For geodetic areas,\n          install Geosphere package and re-run get_area"
## [1] "WARNING: Geosphere Package is not installed. Planar areas,\n          not geodetic areas were calculated. For geodetic areas,\n          install Geosphere package and re-run get_area"
## [1] "WARNING: Geosphere Package is not installed. Planar areas,\n          not geodetic areas were calculated. For geodetic areas,\n          install Geosphere package and re-run get_area"
## [1] "WARNING: Geosphere Package is not installed. Planar areas,\n          not geodetic areas were calculated. For geodetic areas,\n          install Geosphere package and re-run get_area"
## [1] "WARNING: Geosphere Package is not installed. Planar areas,\n          not geodetic areas were calculated. For geodetic areas,\n          install Geosphere package and re-run get_area"
## [1] "WARNING: Geosphere Package is not installed. Planar areas,\n          not geodetic areas were calculated. For geodetic areas,\n          install Geosphere package and re-run get_area"
## [1] "WARNING: Geosphere Package is not installed. Planar areas,\n          not geodetic areas were calculated. For geodetic areas,\n          install Geosphere package and re-run get_area"
## [1] "WARNING: Geosphere Package is not installed. Planar areas,\n          not geodetic areas were calculated. For geodetic areas,\n          install Geosphere package and re-run get_area"
## [1] "WARNING: Geosphere Package is not installed. Planar areas,\n          not geodetic areas were calculated. For geodetic areas,\n          install Geosphere package and re-run get_area"
## [1] "WARNING: Geosphere Package is not installed. Planar areas,\n          not geodetic areas were calculated. For geodetic areas,\n          install Geosphere package and re-run get_area"
## [1] "WARNING: Geosphere Package is not installed. Planar areas,\n          not geodetic areas were calculated. For geodetic areas,\n          install Geosphere package and re-run get_area"
## [1] "WARNING: Geosphere Package is not installed. Planar areas,\n          not geodetic areas were calculated. For geodetic areas,\n          install Geosphere package and re-run get_area"
## [1] "WARNING: Geosphere Package is not installed. Planar areas,\n          not geodetic areas were calculated. For geodetic areas,\n          install Geosphere package and re-run get_area"
## [1] "WARNING: Geosphere Package is not installed. Planar areas,\n          not geodetic areas were calculated. For geodetic areas,\n          install Geosphere package and re-run get_area"
## [1] "WARNING: Geosphere Package is not installed. Planar areas,\n          not geodetic areas were calculated. For geodetic areas,\n          install Geosphere package and re-run get_area"
## [1] "WARNING: Geosphere Package is not installed. Planar areas,\n          not geodetic areas were calculated. For geodetic areas,\n          install Geosphere package and re-run get_area"
## [1] "WARNING: Geosphere Package is not installed. Planar areas,\n          not geodetic areas were calculated. For geodetic areas,\n          install Geosphere package and re-run get_area"
## [1] "WARNING: Geosphere Package is not installed. Planar areas,\n          not geodetic areas were calculated. For geodetic areas,\n          install Geosphere package and re-run get_area"
## [1] "WARNING: Geosphere Package is not installed. Planar areas,\n          not geodetic areas were calculated. For geodetic areas,\n          install Geosphere package and re-run get_area"
## [1] "WARNING: Geosphere Package is not installed. Planar areas,\n          not geodetic areas were calculated. For geodetic areas,\n          install Geosphere package and re-run get_area"
## [1] "WARNING: Geosphere Package is not installed. Planar areas,\n          not geodetic areas were calculated. For geodetic areas,\n          install Geosphere package and re-run get_area"
## [1] "WARNING: Geosphere Package is not installed. Planar areas,\n          not geodetic areas were calculated. For geodetic areas,\n          install Geosphere package and re-run get_area"
## [1] "WARNING: Geosphere Package is not installed. Planar areas,\n          not geodetic areas were calculated. For geodetic areas,\n          install Geosphere package and re-run get_area"
## [1] "WARNING: Geosphere Package is not installed. Planar areas,\n          not geodetic areas were calculated. For geodetic areas,\n          install Geosphere package and re-run get_area"
## [1] "WARNING: Geosphere Package is not installed. Planar areas,\n          not geodetic areas were calculated. For geodetic areas,\n          install Geosphere package and re-run get_area"
## [1] "WARNING: Geosphere Package is not installed. Planar areas,\n          not geodetic areas were calculated. For geodetic areas,\n          install Geosphere package and re-run get_area"
## [1] "WARNING: Geosphere Package is not installed. Planar areas,\n          not geodetic areas were calculated. For geodetic areas,\n          install Geosphere package and re-run get_area"
## [1] "WARNING: Geosphere Package is not installed. Planar areas,\n          not geodetic areas were calculated. For geodetic areas,\n          install Geosphere package and re-run get_area"
## [1] "WARNING: Geosphere Package is not installed. Planar areas,\n          not geodetic areas were calculated. For geodetic areas,\n          install Geosphere package and re-run get_area"
## [1] "WARNING: Geosphere Package is not installed. Planar areas,\n          not geodetic areas were calculated. For geodetic areas,\n          install Geosphere package and re-run get_area"
## [1] "WARNING: Geosphere Package is not installed. Planar areas,\n          not geodetic areas were calculated. For geodetic areas,\n          install Geosphere package and re-run get_area"
## [1] "WARNING: Geosphere Package is not installed. Planar areas,\n          not geodetic areas were calculated. For geodetic areas,\n          install Geosphere package and re-run get_area"
## [1] "WARNING: Geosphere Package is not installed. Planar areas,\n          not geodetic areas were calculated. For geodetic areas,\n          install Geosphere package and re-run get_area"
## [1] "WARNING: Geosphere Package is not installed. Planar areas,\n          not geodetic areas were calculated. For geodetic areas,\n          install Geosphere package and re-run get_area"
## [1] "WARNING: Geosphere Package is not installed. Planar areas,\n          not geodetic areas were calculated. For geodetic areas,\n          install Geosphere package and re-run get_area"
## [1] "WARNING: Geosphere Package is not installed. Planar areas,\n          not geodetic areas were calculated. For geodetic areas,\n          install Geosphere package and re-run get_area"
## [1] "WARNING: Geosphere Package is not installed. Planar areas,\n          not geodetic areas were calculated. For geodetic areas,\n          install Geosphere package and re-run get_area"
## [1] "WARNING: Geosphere Package is not installed. Planar areas,\n          not geodetic areas were calculated. For geodetic areas,\n          install Geosphere package and re-run get_area"
## [1] "WARNING: Geosphere Package is not installed. Planar areas,\n          not geodetic areas were calculated. For geodetic areas,\n          install Geosphere package and re-run get_area"
## [1] "WARNING: Geosphere Package is not installed. Planar areas,\n          not geodetic areas were calculated. For geodetic areas,\n          install Geosphere package and re-run get_area"
## [1] "WARNING: Geosphere Package is not installed. Planar areas,\n          not geodetic areas were calculated. For geodetic areas,\n          install Geosphere package and re-run get_area"
## [1] "WARNING: Geosphere Package is not installed. Planar areas,\n          not geodetic areas were calculated. For geodetic areas,\n          install Geosphere package and re-run get_area"
## [1] "WARNING: Geosphere Package is not installed. Planar areas,\n          not geodetic areas were calculated. For geodetic areas,\n          install Geosphere package and re-run get_area"
## [1] "WARNING: Geosphere Package is not installed. Planar areas,\n          not geodetic areas were calculated. For geodetic areas,\n          install Geosphere package and re-run get_area"
## [1] "WARNING: Geosphere Package is not installed. Planar areas,\n          not geodetic areas were calculated. For geodetic areas,\n          install Geosphere package and re-run get_area"
## [1] "WARNING: Geosphere Package is not installed. Planar areas,\n          not geodetic areas were calculated. For geodetic areas,\n          install Geosphere package and re-run get_area"
## [1] "WARNING: Geosphere Package is not installed. Planar areas,\n          not geodetic areas were calculated. For geodetic areas,\n          install Geosphere package and re-run get_area"
## [1] "WARNING: Geosphere Package is not installed. Planar areas,\n          not geodetic areas were calculated. For geodetic areas,\n          install Geosphere package and re-run get_area"
## [1] "WARNING: Geosphere Package is not installed. Planar areas,\n          not geodetic areas were calculated. For geodetic areas,\n          install Geosphere package and re-run get_area"
## [1] "WARNING: Geosphere Package is not installed. Planar areas,\n          not geodetic areas were calculated. For geodetic areas,\n          install Geosphere package and re-run get_area"
## [1] "WARNING: Geosphere Package is not installed. Planar areas,\n          not geodetic areas were calculated. For geodetic areas,\n          install Geosphere package and re-run get_area"
## [1] "WARNING: Geosphere Package is not installed. Planar areas,\n          not geodetic areas were calculated. For geodetic areas,\n          install Geosphere package and re-run get_area"
## [1] "WARNING: Geosphere Package is not installed. Planar areas,\n          not geodetic areas were calculated. For geodetic areas,\n          install Geosphere package and re-run get_area"
## [1] "WARNING: Geosphere Package is not installed. Planar areas,\n          not geodetic areas were calculated. For geodetic areas,\n          install Geosphere package and re-run get_area"
## [1] "WARNING: Geosphere Package is not installed. Planar areas,\n          not geodetic areas were calculated. For geodetic areas,\n          install Geosphere package and re-run get_area"
## [1] "WARNING: Geosphere Package is not installed. Planar areas,\n          not geodetic areas were calculated. For geodetic areas,\n          install Geosphere package and re-run get_area"
## [1] "WARNING: Geosphere Package is not installed. Planar areas,\n          not geodetic areas were calculated. For geodetic areas,\n          install Geosphere package and re-run get_area"
## [1] "WARNING: Geosphere Package is not installed. Planar areas,\n          not geodetic areas were calculated. For geodetic areas,\n          install Geosphere package and re-run get_area"
## [1] "WARNING: Geosphere Package is not installed. Planar areas,\n          not geodetic areas were calculated. For geodetic areas,\n          install Geosphere package and re-run get_area"
## [1] "WARNING: Geosphere Package is not installed. Planar areas,\n          not geodetic areas were calculated. For geodetic areas,\n          install Geosphere package and re-run get_area"
## [1] "WARNING: Geosphere Package is not installed. Planar areas,\n          not geodetic areas were calculated. For geodetic areas,\n          install Geosphere package and re-run get_area"
## [1] "WARNING: Geosphere Package is not installed. Planar areas,\n          not geodetic areas were calculated. For geodetic areas,\n          install Geosphere package and re-run get_area"
## [1] "WARNING: Geosphere Package is not installed. Planar areas,\n          not geodetic areas were calculated. For geodetic areas,\n          install Geosphere package and re-run get_area"
## [1] "WARNING: Geosphere Package is not installed. Planar areas,\n          not geodetic areas were calculated. For geodetic areas,\n          install Geosphere package and re-run get_area"
## [1] "WARNING: Geosphere Package is not installed. Planar areas,\n          not geodetic areas were calculated. For geodetic areas,\n          install Geosphere package and re-run get_area"
## [1] "WARNING: Geosphere Package is not installed. Planar areas,\n          not geodetic areas were calculated. For geodetic areas,\n          install Geosphere package and re-run get_area"
## [1] "WARNING: Geosphere Package is not installed. Planar areas,\n          not geodetic areas were calculated. For geodetic areas,\n          install Geosphere package and re-run get_area"
## [1] "WARNING: Geosphere Package is not installed. Planar areas,\n          not geodetic areas were calculated. For geodetic areas,\n          install Geosphere package and re-run get_area"
## [1] "WARNING: Geosphere Package is not installed. Planar areas,\n          not geodetic areas were calculated. For geodetic areas,\n          install Geosphere package and re-run get_area"
## [1] "WARNING: Geosphere Package is not installed. Planar areas,\n          not geodetic areas were calculated. For geodetic areas,\n          install Geosphere package and re-run get_area"
## [1] "WARNING: Geosphere Package is not installed. Planar areas,\n          not geodetic areas were calculated. For geodetic areas,\n          install Geosphere package and re-run get_area"
## [1] "WARNING: Geosphere Package is not installed. Planar areas,\n          not geodetic areas were calculated. For geodetic areas,\n          install Geosphere package and re-run get_area"
## [1] "WARNING: Geosphere Package is not installed. Planar areas,\n          not geodetic areas were calculated. For geodetic areas,\n          install Geosphere package and re-run get_area"
## [1] "WARNING: Geosphere Package is not installed. Planar areas,\n          not geodetic areas were calculated. For geodetic areas,\n          install Geosphere package and re-run get_area"
## [1] "WARNING: Geosphere Package is not installed. Planar areas,\n          not geodetic areas were calculated. For geodetic areas,\n          install Geosphere package and re-run get_area"
## [1] "WARNING: Geosphere Package is not installed. Planar areas,\n          not geodetic areas were calculated. For geodetic areas,\n          install Geosphere package and re-run get_area"
## [1] "WARNING: Geosphere Package is not installed. Planar areas,\n          not geodetic areas were calculated. For geodetic areas,\n          install Geosphere package and re-run get_area"
## [1] "WARNING: Geosphere Package is not installed. Planar areas,\n          not geodetic areas were calculated. For geodetic areas,\n          install Geosphere package and re-run get_area"
## [1] "WARNING: Geosphere Package is not installed. Planar areas,\n          not geodetic areas were calculated. For geodetic areas,\n          install Geosphere package and re-run get_area"
## [1] "WARNING: Geosphere Package is not installed. Planar areas,\n          not geodetic areas were calculated. For geodetic areas,\n          install Geosphere package and re-run get_area"
## [1] "WARNING: Geosphere Package is not installed. Planar areas,\n          not geodetic areas were calculated. For geodetic areas,\n          install Geosphere package and re-run get_area"
## [1] "WARNING: Geosphere Package is not installed. Planar areas,\n          not geodetic areas were calculated. For geodetic areas,\n          install Geosphere package and re-run get_area"
## [1] "WARNING: Geosphere Package is not installed. Planar areas,\n          not geodetic areas were calculated. For geodetic areas,\n          install Geosphere package and re-run get_area"
## [1] "WARNING: Geosphere Package is not installed. Planar areas,\n          not geodetic areas were calculated. For geodetic areas,\n          install Geosphere package and re-run get_area"
## [1] "WARNING: Geosphere Package is not installed. Planar areas,\n          not geodetic areas were calculated. For geodetic areas,\n          install Geosphere package and re-run get_area"
## [1] "WARNING: Geosphere Package is not installed. Planar areas,\n          not geodetic areas were calculated. For geodetic areas,\n          install Geosphere package and re-run get_area"
## [1] "WARNING: Geosphere Package is not installed. Planar areas,\n          not geodetic areas were calculated. For geodetic areas,\n          install Geosphere package and re-run get_area"
## [1] "WARNING: Geosphere Package is not installed. Planar areas,\n          not geodetic areas were calculated. For geodetic areas,\n          install Geosphere package and re-run get_area"
```

Finally, let's look at code that would allow us to visualize the result. 
(Remember, though, that this prediction is not valid,
since our MCMC chains were very short and we've only generated 5 contours.) 

```r
image(cont_prob, col = viridis(10))
plot(land, add = T, col = 'grey')
```

![plot of chunk visualize prob forecast](figure/visualize prob forecast-1.png)
We've now produced a contour forecast for sea ice presence. Forecasts of this kind
can be used as is or can be used as a component in a Mixture Contour Forecast (MCF). 
(see the next vignette in the *IceCast* package,*Mixture Contour Forecasting*,
for details). 

### References

Copernicus Climate Change Service (2019). Description of the c3s seasonal multi-system.https://confluence.ecmwf.int/display/COPSRV/Description+of+the+C3S+seasonal+multi-system

Comiso, J., 2017. Bootstrap sea ice concentrations from Nimbus-7 SMMR and 
DMSP SSM/I-SSMIS. version 3. Boulder, Colorado USA: NASA National Snow and
Ice Data Center Distributed Active Archive Center

Director. H. M. A. E. Raftery, and C. M. Bitz, 2020, "Probabilistic Forecasting
of the Arctic Sea Ice Edge With Contour Modeling." https://arxiv.org/abs/1908.09377

Director, H. M., A.E. Raftery, and C. M. Bitz, 2017. "Improved Sea Ice Forecasting 
through Spatiotemporal Bias Correction." Journal of Climate 30.23: 9493-9510.

Nychka D., Furrer R., Paige J., Sain S. (2017). “fields: Tools for spatial data.”.
R package version 9.8, https://cran.r-project.org/web/packages/fields/index.html.

Simon Garnier (2018). "viridis: Default Color Maps from 'matplotlib'". R package version 0.5.1.
  https://CRAN.R-project.org/package=viridis.
  
Sea Ice Prediction Network (2019). Sea ice prediction network
predictability portal. https://atmos.uw.edu/sipn/.

