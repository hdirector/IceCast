## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)

## ----load package, message = FALSE, warning = FALSE---------------------------
library("IceCast")
library("viridis")
library("fields")

## ----time info----------------------------------------------------------------
month <- 9
train_start_year <- 1993
train_end_year <- 2007
level <- 15
train_bc_start_year <- 1993

## ----mcmc info----------------------------------------------------------------
n_iter <- 100
burn_in <- 10

## ----obs data info, eval = FALSE----------------------------------------------
#  ##Not run##
#  # obs_file_path <- 'path_to_observation_data'
#  # bs_version <- 3.1
#  # dat_type_obs <- "bootstrap"
#  # obs <- read_monthly_BS(start_year = train_bc_start_year, end_year = train_end_year,
#  #                        version = bs_version, file_folder = obs_file_path)

## ----find y, eval = FALSE-----------------------------------------------------
#  # ## Not run ##
#  # y_train <- find_y(start_year = train_start_year, end_year = train_end_year,
#  #                   obs_start_year = train_start_year,
#  #                   pred_start_year = NULL, observed = obs[train_ind, month,,],
#  #                   predicted = NULL, reg_info, month, level,
#  #                   dat_type_obs, dat_type_pred, obs_only = TRUE)

## ----identify regions---------------------------------------------------------
temp <- to_fit(y_train$obs, reg_info)
regs_to_fit <- temp$regs_to_fit
full <- temp$full

## ----y to prop----------------------------------------------------------------
prop_train <- y_to_prop(y = y_train$obs, regs_to_fit, reg_info)
prop_train <- lapply(prop_train, function(y){sapply(y, function(x){x})})

## ----prop to pi---------------------------------------------------------------
eps <- .01
prop_train_tilde <- list()
for (r in regs_to_fit) {
  ub_ind <- which(prop_train[[r]] >= 1 - eps)
  prop_train[[r]][ub_ind] <- 1 - eps
  lb_ind <- which(prop_train[[r]] <= eps)
  prop_train[[r]][lb_ind] <- eps
  prop_train_tilde[[r]] <- logit(prop_train[[r]])
}

## ----set prior for mu---------------------------------------------------------
data(prop_bc)

## ----prior bounds for sigma---------------------------------------------------
data("ub_props")
data("lb_props")

## ----run mcmc-----------------------------------------------------------------
res_short <- list()
for (r in regs_to_fit) {
  res_short[[r]] <- fit_cont_pars(r = r, n_iter = n_iter,
                                  prop_tilde = prop_train_tilde[[r]],
                                  reg_info = reg_info, prop0 = prop_bc[[r]],
                                  ub_prop = ub_props[r], lb_prop = lb_props[r])
}

## ----estimate parameters------------------------------------------------------
pars <- list()
for (r in regs_to_fit) {
  pars[[r]] <- calc_pars(res_r = res_short[[r]], burn_in, r = r)
}

## ----generate indiv contours--------------------------------------------------
indiv_conts <- list()
n_gen <- 5
for (r in regs_to_fit) {
  indiv_conts[[r]] <- gen_cont(r, pars_r = pars[[r]], reg_info, n_gen,
                               rand = res_short[[r]]$rand, start = res_short[[r]]$start,
                               start_inds = res_short[[r]]$start_inds,
                               end = res_short[[r]]$end, end_inds = res_short[[r]]$end_inds)
 }

## ----merge contours-----------------------------------------------------------
conts <- merge_conts(conts = indiv_conts, full = full)

## ----plot sample contours-----------------------------------------------------
par(mfrow = c(1, 2), oma = rep(0, 4), mar = rep(0, 4))
plot(land, col = 'grey')
plot(conts[[1]], add = T, col = 'blue')

## -----------------------------------------------------------------------------
cont_prob <- prob_map(merged = conts)

## ----visualize prob forecast--------------------------------------------------
image(cont_prob, col = viridis(10))

