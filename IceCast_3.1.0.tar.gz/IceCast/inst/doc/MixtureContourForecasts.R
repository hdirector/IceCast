## ----load package,  message = FALSE, warning = FALSE--------------------------
library("IceCast")

## ---- fit weights-------------------------------------------------------------
weight <- fit_weights(mod1 = cont_9_2005_2007, mod2 = clim_9_2005_2007,
                      obs = obs_9_2005_2007, prop_area = prop_area)

## ---- apply weights, fig.height = 5, fig.width  = 5---------------------------
MCF_9_2008 <- wght_mod(w = weight, mod1 = cont_9_2008, mod2 = clim_9_2008)

## ---- load packages,  message = FALSE, warning = FALSE------------------------
library("fields")
library("viridis")

## ----plotting details---------------------------------------------------------
#dimension of polar Sterographic grid
nX <- 304; nY <- 448 

#x-coordinates
xmn = -3850; xmx = 3750 
xBd <- seq(xmn, xmx, 25)

#y-coordinates
ymn = -5350; ymx = 5850 
yBd <- seq(ymn, ymx, 25)

## ----zoom in------------------------------------------------------------------
#zoomed-in area
xBdInd <- 60:215; xBdN <- length(xBdInd) 
yBdInd <- 130:310; yBdN <- length(yBdInd)

## ----coloring for land--------------------------------------------------------
#land 
MCF_9_2008[is.na(MCF_9_2008)] <- 101/100 

#region and ocean masks
all_regions_mask <- conv_to_grid(all_regions)
non_reg_ocean <- matrix(nrow = nX, ncol = nY, data = 0)
non_reg_ocean[all_regions_mask == 0] <- 1
MCF_9_2008[non_reg_ocean == 1] <- 102/100

## ---- fig.height = 6, fig.width  = 7, fig.align = "center"--------------------
#plot MCF probabilities
layout(matrix(data = c(rep(1, 10), 2), ncol = 11))
par(oma = rep(2, 4), mar = rep(0, 4))
image(xBd[xBdInd], yBd[yBdInd], MCF_9_2008[xBdInd[1:(xBdN - 1)], yBdInd[1:(yBdN - 1)]],
      xaxt = "n", yaxt = "n", col = c(rep(viridis(10), each = 10), "grey", "beige"),
      zlim = c(0, 102/100), xlab = "", ylab = "", main = "Mixture Contour Forecast",
      cex.main = 1.6)

#plot observed ice edge
plot(obs_9_2008_poly,  add = T, border = "red", lwd = 1)

#add legend
legend("bottom", fill = c("grey", "beige", NA), 
       legend = c("land", "Outside Region", "Observed Contour"),
       lty = c(NA, NA, 1), pch = c(22, 22, NA), ncol = 3, cex = 1,
       col = c("white", "white", "red"), lwd = c(NA, NA, 2),
       bg = 'white', border = c("black", "black", "white"),
       pt.cex = c(3, 3, 3), text.font = 2)

#add color bar
plot.new()
image.plot(MCF_9_2008, zlim = c(0, 1), col = viridis(10), legend.only = TRUE,
           legend.width = 4, legend.shrink = .75)

