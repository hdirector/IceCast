#' Generate the contours for a particular region given the model prediction
#' @title Generate contours
#' @param r integer indicating the number of the region in which the contours
#'          should be generated
#' @param pars_r List of parameter information for region r. The list should contain
#'            two elements, \code{muEst} and \code{sigmaEst}, which give
#'            estimates for the \eqn{\mu} and \eqn{\Sigma} parameters used in
#'            generating contours. Typically obtained from the \code{calc_pars}
#'            function
#' @param reg_info  a \code{reg_info} list (see documentation for \code{reg_info})
#' @param n_gen integer specifying the number of contours to be generated, must
#'              be at least 2
#' @param rand indices of line lengths that will be generated randomly
#' @param start character of value "ones", "zeros", or "rand" indicating
#'              if the proportions at the start of the set of lines
#'              are all ones, all zeros, or generated randomly
#' @param start_inds indices of lines in the starting set of lines
#' @param end character of value "ones", "zeros", or "rand" indicating
#'            if the proportions at the end of the set of lines
#'            are all ones, all zeros, or generated randomly
#' @param end_inds indices of lines in the ending set of lines
#' @importFrom rgeos gIntersection gDifference
#' @importFrom MASS mvrnorm
#' @importFrom sp SpatialPolygons
gen_cont <- function(r, pars_r, reg_info, n_gen, rand, start, start_inds,
                     end, end_inds) {
  stopifnot(n_gen >= 2)

  #initial info
  n_lines <- length(pars_r$mu_est)
  angs_r <- reg_info$angs[[r]]
  y_max <- sapply(reg_info$sec_lengths[[r]], sum) #max lengths (with land)

  #generate tranformed proportions and convert back to lengths
  prop_tilde_gen = mvrnorm(n_gen, pars_r$mu_est, pars_r$sigma_est)
  prop_gen <- ilogit(prop_tilde_gen)
  y_gen <- apply(prop_gen, 1, function(x){prop_to_y(prop = x, r, reg_info,
                                                    inds = rand)})
  y_gen[y_gen <= 12.5] <- 0

  #fixed start points if applicable
  if (start == "zeros") {
    start_pts <- reg_info$start_coords[[r]][start_inds,]
  } else if (start == "ones") {
    start_pts <- reg_info$start_coords[[r]][start_inds,] +
                 cbind(y_max[start_inds]*cos(angs_r[start_inds]),
                       y_max[start_inds]*sin(angs_r[start_inds]))
  }

  #fixed end points if applicable
  if (end == "zeros") {
    end_pts <- reg_info$start_coords[[r]][end_inds,]
  } else if (end == "ones") {
    end_pts <- reg_info$start_coords[[r]][end_inds,] +
               cbind(y_max[end_inds]*cos(angs_r[end_inds]),
                     y_max[end_inds]*sin(angs_r[end_inds]))
  }

  #make contours out of x's and y's
  conts_r <- list()
  for (k in 1:n_gen) {
    #random points
    angs_r <- reg_info$angs[[r]]
    new_pts <- reg_info$start_coords[[r]][rand,] +
                cbind(y_gen[,k]*cos(angs_r[rand]),
                      y_gen[,k]*sin(angs_r[rand]))

    #add fixed points at the start
    if (start == "ones"| start == "zeros") {
      new_pts <- rbind(start_pts, new_pts)
    }

    #add fixed points at the end
    if (end == "ones"| end == "zeros") {
      new_pts <- rbind(new_pts, end_pts)
    }

    #make new polygons
    conts_r[[k]] <- make_polygons(r, my_end = new_pts, poly_name = "new")
  }
  return(conts_r)
}


#' Convert proportion  to line length
#'
#' Convert the ice-covered proportion of a line to the total length that
#' that ice-covered portion extends. (Note that this length includes
#' the length of sections where the line crosses land, unlike for the
#' \code{y_to_prop} function).
#' @param prop numeric value between 0 and 1
#' @param r number indicating the region being analyzed. Numbering matches
#' \code{reg_info} region numbering
#' @param reg_info  a \code{reg_info} list (see documentation for \code{reg_info})
#' @param inds indices of lines that are being generated
prop_to_y <- function(prop, r, reg_info, inds) {
  sec_lengths_r <- reg_info$sec_lengths[[r]][inds]
  cumprops_r <- reg_info$cumprops[[r]][inds]
  max_lengths_r <- reg_info$max_lengths[[r]][inds]
  n_lines <- length(prop)
  y <- rep(NA, n_lines)
  for (i in 1:n_lines) {
    if (abs(prop[i] - 1) <= 1e-7) { #simplest case, fully covered
      y[i] <- sum(sec_lengths_r[[i]])
    } else {
      prop_greater <- prop[i] >= cumprops_r[[i]]
      if (any(prop_greater, na.rm = T)) {
        #index of section where only a portion of the length will be used
        calc_ind <- min(which(!prop_greater))
        y_use_all <- sum(sec_lengths_r[[i]][1:(calc_ind - 1)]) #proportion used in complete sections
        prop_left <- prop[i] - cumprops_r[[i]][calc_ind - 2] #proportion left to use incomplete section
        prop_in_calc <- cumprops_r[[i]][calc_ind] - cumprops_r[[i]][calc_ind - 2] #proportion of total in incomplete section
        y_calc <- (prop_left/prop_in_calc)*sec_lengths_r[[i]][calc_ind]
        y[i] <- y_use_all + y_calc
      } else {
        y[i] <- prop[i]*max_lengths_r[i]
      }
    }
  }
  return(y)
}

#' Merge generated contours for all regions together
#' @title Merge contours
#' @param conts list of contours organized as a list of regions by a list of
#' years by a list of samples
#' @param full \code{SpatialPolygons} object for area to be included in all
#'             generated contours
#' @return Returns a list of contours organized as a list of years by a list of
#'  samples
#' @importFrom raster aggregate
#' @importFrom maptools spRbind
#' @export
merge_conts <- function(conts, full) {
  first <- min(which(sapply(conts, function(x){!is.null(x)})))
  n_gen <- length(conts[[first]])
  merged <- list()
  reg_fit <- which(sapply(conts, function(x){!is.null(x)}))
  for (i in 1:n_gen) {
    temp <- NULL
    for (r in reg_fit) {
      if (i <= length(conts[[r]])) {#if last polygon is empty, no value for index i
        if (!is.null(conts[[r]][[i]])) { #ignore NULL (empty) polygons
          if (!is.null(temp) && !is.null(conts[[r]][[i]])) { #add new polygon
            temp <- raster::aggregate(spRbind(temp, conts[[r]][[i]]))
          } else { #first polygon
            temp <- conts[[r]][[i]]
          }
        }
        temp@polygons[[1]]@ID <- "genCont"
      }
    }
    if (is(full)[1] == "SpatialPolygons") {
      temp <- raster::aggregate(spRbind(temp, full))
    } else {
      temp <- raster::aggregate(temp)
    }
    merged[[i]] <- temp
  }
  return(merged)
}

#' Compute Probabilities from Generated Contours
#'
#' Produces a longitude x latitude grid of predicted sea ice probability from
#' a list of \code{SpatialPolygon} objects outputted from the function \code{merge_conts}
#' @param merged 	list of contours organized as a list of years by a list of
#'                sampled contours. The contours are \code{SpatialPolygons} objects.
#' @param nX dimension in the x (defaults to value for Northern Polar
#'           Stereographic grid: 304)
#' @param nY dimension in the y (defaults to value for Northern Polar
#'           Stereographic grid: 448)
#' @return array of dimension number of years by longitude by latitude that
#' gives the proportion of contours in which the grid box is ice-covered
#' @export
#' @examples
#' \dontrun{ probs <- prob_map(merged) }
#'
prob_map <- function(merged, nX = 304, nY = 448) {
  n_gen <- length(merged)
  indiv <- array(dim = c(n_gen, nX, nY))
  for (i in 1:n_gen) {
    indiv[i,,] <- conv_to_grid(merged[[i]])
  }
  map <- apply(indiv, 2:3, mean)
  return(map)
}


