# -------------------------------------
# main function
# -------------------------------------
#' MCMC Sampler for Contour Model
#'
#' Sets up and runs the MCMC sampler to fit the parameters of the contour model
#'
#' @param r number indicating which region in the \code{reg_info} list to
#'          evaluate
#' @param n_iter number of iterations to run the MCMC chain
#' @param prop_tilde matrix of dimension number of lines by number of training years
#'                   that gives the logit-transformed observed proportions
#' @param reg_info  a \code{reg_info} list (see documentation for \code{reg_info})
#' @param prop0 vector of with length matching the number of lines in region \code{r}
#'  giving the prior mean proportions
#' @param ub_prop max proportion, typically 0.99
#' @param lb_prop min proportion, typically 0.01
#' @param alpha_kappa0 parameter a for a \eqn{Unif(a, b)} prior on \eqn{\alpha}
#' @param beta_kappa0 parameter b for a \eqn{Unif(a, b)} prior on \eqn{\beta}
#' @param mu_prop_sd standard deviation for normal proposal for \eqn{\mu}
#' @param sigma_prop_sd standard deviation for normal proposal for \eqn{\sigma}
#' @param prop0_range parameter used to determine prior for \eqn{\mu_{0}}. Prior
#' distribution is assumed to have the standard deviation corresponding to a
#' Normal distribution with 95 percent of its mass in the interval (\eqn{\mu_{0}} - \code{prop0_range},
#' \eqn{\mu_{0}} + \code{prop0_range})
#' @param kappa_ini initial value for \eqn{\kappa}
#' @param kappa_prop_sd standard deviation for proposal for \eqn{\kappa}
#' @param sigma_min minimum value for all \eqn{\sigma} parameters.
#'                 Typically close to but not exactly zero (defaults to 0.01).
#'                 Not used if \code{sigma0_lb} is set to \code{NULL}
#' @param eps value defining rounding of proportion data. Proportions below
#' \code{eps} are rounded to \code{eps} and proportions above 1 - \code{eps} are
#' rounded to 1 - \code{eps}
#' @param buff how many extra no-variability lines should be included,
#' defaults to zero
#' @return List that gives the values of the MCMC chain for
#'         \eqn{\mu} (\code{mu}), \eqn{\sigma} (\code{sigma}), and \eqn{\kappa} (\code{kappa}) along with
#'         indicators of acceptance on each iteration,
#'         \code{sigmaRate}, \code{muRate}, and \code{kappaRate}.
#' @importFrom stats cov qnorm sd
#' @export
fit_cont_pars <- function(r, n_iter, prop_tilde, reg_info, prop0,
                          ub_prop, lb_prop,
                          alpha_kappa0 = .05, beta_kappa0 = 20,
                          mu_prop_sd = .25, sigma_prop_sd = .2,
                          prop0_range = .125, kappa_ini = 1, kappa_prop_sd = .1,
                          sigma_min = .01, eps = .01, buff = 0) {

  #narrow in on lines with variability + buffer
  fit_info <- lines_to_fit(prop_tilde = prop_tilde, eps = eps, buff = buff)
  fit_ind <- fit_info$rand
  n_lines <- length(fit_ind)
  prop_tilde_fit <- prop_tilde[fit_ind,]
  prop0 <- prop0[fit_ind]

  #distance matrix
  if (r == 1) {
    angs <- reg_info$angs[[1]][fit_ind]
    angs2pi <- angs
    angs2pi[angs < 0] <- pi + (pi + angs[angs < 0])
    dists <- theta_dist_mat(thetas = angs2pi)
  } else {
    dists <- dist_mat(n_lines)
  }

  #priors
  mu0 <- logit(prop0)
  prop0_lb <- prop0 - prop0_range
  prop0_lb[prop0_lb <= eps] <- eps
  prop0_ub <- prop0 + prop0_range
  prop0_ub[prop0_ub >= 1 - eps] <- 1 - eps
  lambda0 <- ((logit(prop0_ub) - logit(prop0_lb))/2)/qnorm(.995)
  Lambda0 <- diag(lambda0^2)
  beta_sigma0 <- rep(((logit(ub_prop) - logit(lb_prop))/2)/qnorm(.995),
                    n_lines)

  #Initial values
  emp_cov_y <- cov(t(prop_tilde_fit))
  mu_ini <- apply(prop_tilde_fit, 1, mean)
  sigma_ini <- sqrt(diag(emp_cov_y))
  sigma_high <- which(sigma_ini >= beta_sigma0)
  sigma_ini[sigma_high] <- beta_sigma0[sigma_high] - .2
  sigma_ini[which(sqrt(diag(emp_cov_y)) < sigma_min)] <- sigma_min

  #MCMC parameters
  mu_prop_sd <- rep(mu_prop_sd, n_lines)
  sigma_prop_sd = rep(sigma_prop_sd, n_lines)

  res <- RunMCMC(nIter = n_iter, prop_tilde = prop_tilde_fit, mu = mu_ini,
                 mu0 = mu0, Lambda0 = Lambda0, muPropSD = mu_prop_sd,
                 kappa = kappa_ini, alphaKappa0 = alpha_kappa0,
                 betaKappa0 = beta_kappa0, kappaPropSD  = kappa_prop_sd,
                 sigma = sigma_ini, sigmaMin = sigma_min, betaSigma0 = beta_sigma0,
                 sigmaPropSD = sigma_prop_sd, dists = dists)

  #return info about fixed and random points
  res$rand = fit_info$rand
  res$start <- fit_info$start
  res$start_inds <- fit_info$start_inds
  res$end <- fit_info$end
  res$end_inds <- fit_info$end_inds

  return(res)
}

# -------------------------------------------------------
# Related to setting up MCMC: priors, boundary info, etc.
# -------------------------------------------------------
#' Find angle distance between two angle measures in range (0, 2pi)
#' @title Distance between angles
#' @param a angle value in the range [0, 2\eqn{\pi}]
#' @param b angle value in the range [0, 2\eqn{\pi}]
ang_dist <- function(a, b) {
  stopifnot(a >= 0); stopifnot(b >= 0)
  stopifnot(a <= 2*pi); stopifnot(b <= 2*pi)
  if (a == b) {
    return(0)
  } else {
    p1 <- min(a, b); p2 <- max(a, b)
    return(min(p2 - p1, p1 + (2*pi - p2)))
  }
}

#' Make a matrix of the distance between angles
#' @param thetas vector of angles of interest
theta_dist_mat <- function(thetas) {
  n <- length(thetas)
  dist_mat <- matrix(nrow = n, ncol = n)
  for (i in 1:n) {
    for (j in 1:n) {
      dist_mat[i,j] <- ang_dist(thetas[i], thetas[j])
    }
  }
  return(dist_mat)
}

#' Determine fixed section of lines
#'
#' Identify contiguous sets of lines with no variability in their ice-covered
#' length.
#'
#' @param prop_tilde matrix of dimension number of lines by number of years
#' giving the observed transformed proportion
##' @param eps value defining rounding of proportion data. Proportions below
#' \code{eps} are rounded to \code{eps} and proportions above 1 - \code{eps} are
#' rounded to 1 - \code{eps}
#' @param buff how many extra no-variability lines should be included,
#' defaults to zero
lines_to_fit <- function(prop_tilde, eps, buff = 0) {
  #find indices on boundaries
  n_lines <- nrow(prop_tilde)
  at_lb <- apply(prop_tilde, 1, function(x){all(x == logit(eps))})
  at_ub <- apply(prop_tilde, 1, function(x){all(x == logit(1 - eps))})

  #find if start of lines is all zeros or all ones
  if (all(at_lb[1:(1 + buff)] == TRUE)) {
    start <- "zeros"
    trans <- min(which(diff(at_lb) == -1))
    start_inds <- 1:(trans - buff)
  } else if (all(at_ub[1:(1 + buff)] == TRUE)) {
    start <- "ones"
    trans <- min(which(diff(at_ub) == -1))
    start_inds <- 1:(trans - buff)
  } else {
    start <- "rand"
    start_inds <- c()
  }

  #find if end of lines is all zeros or all ones
  if (all(at_lb[(n_lines - buff):n_lines] == TRUE)) {
    end <- "zeros"
    trans <- max(which(diff(at_lb) == 1))
    end_inds <- ((trans + 1) + buff):n_lines
  } else if (all(at_ub[(n_lines - buff):n_lines] == TRUE)) {
    end <- "ones"
    trans <- max(which(diff(at_ub) == 1))
    end_inds <- ((trans + 1) + buff):n_lines
  } else {
    end <- "rand"
    end_inds <- c()
  }

  #find remaining points that will be randomly generated
  rand <- 1:n_lines
  rand <- rand[!(rand %in% start_inds)]
  rand <- rand[!(rand %in% end_inds)]

  #add additional fitted points if only one point is initially set to be fit,
  #(rare case)
  if (length(rand) == 1) {
    rand <- (rand - 1):(rand + 1)
    start_inds <- start_inds[1:(length(start_inds) - 1)]
    end_inds <- end_inds[2:(length(end_inds))]
  }

  return(list("rand" = rand, "start" = start, "start_inds" = start_inds,
              "end" = end, "end_inds" = end_inds))
}


#' Compute 'distances' among \eqn{n} lines
#'
#' Create a matrix specifying the differences of indices from an ordered
#' set of indices from \eqn{(1, 2, ...,} \code{n_lines}\eqn{)}. For lines with
#'  indices \eqn{i} and \eqn{j},
#' the 'distance' computed is \eqn{|i -j|}. Results are used to define covariance.
#' @param n_lines number of lines in matrix
#' @return Matrix of `distances' among the indices
dist_mat <- function(n_lines) {
  dists <- matrix(nrow = n_lines, ncol = n_lines)
  #compute distance as sequences of locations along a path
  for (i in 1:n_lines) {
    for (j in 1:i) {
      dists[i, j] <- dists[j, i] <- abs(i - j)
    }
  }
  return(dists)
}

# ---------------------------------------------
# related to finding y and info from it
# ----------------------------------------------

#' Identify fully ice-covered and ice-free regions
#'
#' Determine which regions are completely ice-filled (full) or ice-free (empty)
#' in all years in the training period. Also, make a \code{SpatialPolygons} object
#' giving all regions that are fully ice-covered.
#'
#' @param y_obs list of y values outputted from \code{y_obs} function
#' @param reg_info  a \code{reg_info} list (see documentation for \code{reg_info})
#' @importFrom maptools spRbind
#' @importFrom raster aggregate
to_fit <- function(y_obs, reg_info) {
  n_reg <- length(reg_info$regions)
  empty <- full <- rep(FALSE, n_reg)

  #determine which regions are completely ice-filled (full) or ice-free in all
  #years in training period
  for (r in 1:n_reg) {
    if (all(sapply(y_obs[[r]], function(x){all(x == 0)}))) {
      empty[r] <- TRUE
    } else if (all(apply(sapply(y_obs[[r]], function(x){x}), 1, sd) < 1e-15)) {
      full[r] <- TRUE
    }
  }
  regs_to_fit <- which(!empty & !full)
  reg_full <- which(full)

  #Make a polygon of all regions that are fully filled with sea ice
  full <- NA
  nRegsFull <- length(reg_full)
  if (length(reg_full) > 0) {
    full <- reg_info$regions[[reg_full[[1]]]]
    full@polygons[[1]]@ID <- "regsFull"
    if (length(reg_full) > 1) {
      for (i in 2:nRegsFull) {
        full <- aggregate(spRbind(full, reg_info$regions[[reg_full[[i]]]]))
        full@polygons[[1]]@ID <- "regsFull"
      }
    }
    full <- gDifference(full, land)
  }

  return(list("regs_to_fit" = regs_to_fit, "full" = full))
}

# ----------------------------------------------
# computing parameters from MCMC results
# ----------------------------------------------

#' Compute Parameters Estimates
#'
#' Compute parameter estimates for the contour model using MCMC output from
#' the function \code{fit_cont_pars}
#' @param res_r output of function \code{fit_cont_pars} giving the MCMC
#'              chains for one region
#' @param burn_in number of iterations to discard as burn-in. This is the number
#'               before thinning.
#' @param r index of region
#' @return List of parameters for region \eqn{r} with
#'         elements, \code{muEst} and \code{sigmaEst}. These  give
#'         estimates for the \eqn{\mu} and \eqn{\Sigma} parameters used to
#'         generate contours.
#' @export
calc_pars <- function(res_r, burn_in, r) {
  n_samp <- length(res_r$kappa)
  mu_est <- apply(res_r$mu[,(burn_in + 1):n_samp], 1, mean)
  n_lines <- length(mu_est)
  sigma_est_vec <- apply(res_r$sigma[,(burn_in + 1):n_samp], 1, mean)
  #distance matrix
  if (r == 1) {
    #angles are in a loop, need to account for which points are skipped
    angs <- reg_info$angs[[1]][res_r$rand]
    angs2pi <- angs
    angs2pi[angs < 0] <- pi + (pi + angs[angs < 0])
    dists <- theta_dist_mat(thetas = angs2pi)
  } else {
    #skipped points are at beginning and end, so can just space remaining points
    dists <- dist_mat(n_lines)
  }
  kappa_est <- mean(res_r$kappa[(burn_in + 1):n_samp])
  sigma_est <- compSigma(sigma_est_vec, kappa_est, dists)
  return(list("mu_est" = mu_est, "sigma_est" = sigma_est))
}

#' Convert length to a proportion of total length
#'
#' Convert length of ice-covered length to proportion of the total length which the ice
#' could cover (excludes length on land)
#' @param y vector of length of the number of lines that gives the lengths the ice extends
#' along each line
#' @param regs_to_fit vector giving the indices of which regions to fit
#' @param reg_info a \code{reg_info} list (see documentation for \code{reg_info})
#' @export
y_to_prop <- function(y, regs_to_fit, reg_info){
  n_reg <- length(y)
  prop <- list()
  for (r in regs_to_fit) {
    #compute proportion
    if (is(y[[r]])[1] == "list") {
      prop[[r]] <- lapply(y[[r]], function(x){x/reg_info$max_length[[r]]})
    } else {
      prop[[r]] <- y[[r]]/reg_info$max_length[[r]]
    }
  }
  return(prop)
}


#' Logit transform
#'
#' Compute logit transformation, \eqn{logit(x) = log(1/(1 - x))}.
#' @param x numeric value between (0, 1)
#' @export
logit <- function(x) {
  log(x/(1 - x))
}

#' Inverse logit transform
#'
#' Compute inverse logit transformation, \eqn{ilogit(x) = exp(x)/(1 + exp(x))}
#' @param x numeric value
#' @export
ilogit <- function(x) {
  exp(x)/(1 + exp(x))
}


