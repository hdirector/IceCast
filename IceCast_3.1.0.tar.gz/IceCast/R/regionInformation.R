#' List of information about each region
#'
#' The region information list  provides
#' information about each of the five regions and the lines from which ice extends
#' in those regions. The list has 13 items, which are lists or vectors giving
#' information about each region. The regions and, if applicable,
#' the lines are ordered the same in all items.The regions in this object have been substantially modified from
#' the Seas of the Arctic given by the National Snow and Ice Data Center (2017).
#'
#' \code{regions}: list of \code{SpatialPolygons} objects for each region
#'
#' \code{start_lines}: list of \code{SpatialLines} object giving the line from
#' which each bias correction or generated contour will start. For the central Arctic
#' region, a single \code{SpatialPoint} is used instead
#'
#' \code{start_lines_coords}: list of matrices giving the coordinates that
#' approximately match \code{reg_info$start_lines}, except that these lines extend to
#' touch the end point of the first and last fixed line. For the central Arctic
#' region, the coordinate of the \code{start_line} is just repeated
#'
#' \code{start_coords}: list of matrices giving the coordinates from which the
#' lines start
#'
#' \code{end_coords}: list of matrices giving the coordinates between the end
#' points of the first and last fixed line
#'
#' \code{out}: list of \code{SpatialPolygons} objects that border
#' \code{reg_info$start_lines}, but are outside the region. These are used when
#' building new polygons to determine if points are outside the region of
#' interest
#'
#' \code{lines}: list giving the \code{SpatialLines} objects that correspond to
#' the line on which contours are mapped and built
#'
#' \code{cumprops}: list that gives for each region and line a vector of proportions
#' that correspond to the proportion of the total line length that each section of the
#' line covers. The dividing lines of the section are where the line enters or exits land.
#' The first index of the list gives the region and the second index gives the
#' index of the line
#'
#' \code{sec_lengths}: list that gives for each region and line a vector of lengths
#' that correspond to the length of each section of the line. The dividing lines of
#' the section are where the line enters or exits land.
#' The first index of the list gives the region and the second index gives the
#' index of the line.
#'
#' \code{max_lengths}: list giving a vector of the total length of the
#' line sections of each line that are ocean. The index refers to the region
#' and the elements within each list are for the individual lines
#'
#' \code{land_cats}: list that gives for each region and line an indicator
#' whether each section of the line is land or not. The dividing lines of
#' the section are where the line enters or exits land.
#' The first index of the list gives the region and the second index gives the
#' index of the line.
#'
#' \code{loop}: vector giving a Boolean for each region. The value \code{TRUE}
#'  indicates that the lines are mapped in a circle around a fixed point.
#'  The value \code{FALSE} indicates that the lines are mapped along a line on
#'  land.
#'
#'  \code{angs}: list of vectors giving the angles of the corresponding
#'  \code{reg_info$lines}. Elements ordered the same as \code{reg_info$regions}
#'
#' @keywords datasets
#' @docType data
#' @references
#'              National Snow and Ice Data Center, 2017: Region mask for the
#'              northern hemisphere.
#'              \url{http://nsidc.org/data/polar-stereo/tools_masks.html}.
#'
#' @usage data(reg_info)
"reg_info"
