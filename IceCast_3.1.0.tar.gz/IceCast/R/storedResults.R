#' Computed Y's for September 1993-2008 predictions
#'
#' Output of the \code{find_y} function for predictions from the European Centre
#' for Medium-Range Weather Forecasts (ECMWF) ensemble for September 1993-2008
#' at a lead-time of 1.5 months. Predictions are converted to a Polar Stereographic grid.
#'
#' @docType data
#' @keywords datasets
#' @usage data(y_pred)
#' @references Copernicus Climate Change Service (2019). Description of the c3s
#'             seasonal multi-system.
#'             \url{https://confluence.ecmwf.int/display/CKB/Description+of+the+C3S+seasonal+multi-system}
#'
#'             Sea Ice Prediction Network (2019). Sea ice prediction network
#'             predictability portal. \url{https://atmos.uw.edu/sipn/.}
#' @examples
#' data(y_pred)
"y_pred"

#' Lower bounds for proportion ice-covered
#'
#' Vector with one entry per region giving the lower bound for the proportion of
#' each line that can be ice-covered in each region.
#' @format vector
#' @docType data
#' @keywords datasets
#' @usage data(lb_props)
"lb_props"

#' Upper bounds for proportion ice-covered
#'
#' Vector with one entry per region giving the upper bound for the proportion of
#' each line that can be ice-covered.
#'
#' @docType data
#' @keywords datasets
#' @usage data(ub_props)
"ub_props"

#' Bias-corrected proportions for September 2008
#'
#' Stored data giving the prior for the mean proportion ice covered
#' for a sample month. The prior is based on forecasts from the
#' European Centre for Medium-Range Weather
#' Forecasts (ECMWF) ensemble converted to a Polar Stereographic grid. The
#' prediction is made at a 1.5 month lead time and bias-corrected with Contour-Shifting.
#'
#' @docType data
#' @keywords datasets
#' @references Copernicus Climate Change Service (2019). Description of the c3s
#'             seasonal multi-system.\url{https://confluence.ecmwf.int/display/CKB/Description+of+the+C3S+seasonal+multi-system}
#' @examples
#' data(prop_bc)
"prop_bc"


#' Computed Y's for September 1993-2007 observations
#'
#' Output of the \code{find_y} function for September 1993-2007 using the observed
#' ice edge from the NASA Bootstrap sea ice concentration data. Concentrations
#' above 15 percent are considered to be ice-covered.
#'
#' @docType data
#' @keywords datasets
#' @usage data(y_pred)
#' @references Comiso, J., 2017: Bootstrap sea ice concentrations
#'             from Nimbus-7 SMMR and DMSP SSM/I-SSMIS. version 3.
#'             Boulder, Colorado USA: NASA National Snow and Ice Data Center
#'             Distributed Active Archive Center. doi: \url{https://doi.org/10.5067/7Q8HCCWS4I0R}
"y_train"

#' Computed Y's for September 1993-2007 predictions
#'
#' The object \code{y_month9} is obtained from running the \code{find_y}
#' function for observations and predictions for September 1993-2007.
#' See \code{find_y} for more details on the output.
#'
#' The predictions are from the European Center
#' for Medium-Range Weather Forecasts (ECMWF) ensemble. Predictions are made at
#' a lead time of 2.5-month lead time and are  converted to a Polar Stereographic
#' grid. This model output is available from
#' the Sea Ice Prediction Network Predictability Portal or the Copernicus
#' Climate Change Service data store.
#'
#' The observations are from the NASA Bootstrap monthly
#' sea ice concentration data. These observations are provided by the National
#' Aeronautics and Space
#' Administration (NASA) satellites Nimbus-7 SMMR and DMSP SSM/I-SSMIS and
#' are processed by the Bootstrap algorithm. The results are distributed by the
#' National Snow and Ice Data Center (Comiso 2017).
#'
#' @docType data
#' @format Object obtained from the \code{find_y} function
#'
#' @keywords datasets
#' @references Comiso, J., 2017: Bootstrap sea ice concentrations
#'             from Nimbus-7 SMMR and DMSP SSM/I-SSMIS. version 3.
#'             Boulder, Colorado USA: NASA National Snow and Ice Data Center
#'             Distributed Active Archive Center. doi: \url{https://doi.org/10.5067/7Q8HCCWS4I0R}
#'
#'             Copernicus Climate Change Service (2019). Description of the c3s
#'             seasonal multi-system.\url{https://confluence.ecmwf.int/display/CKB/Description+of+the+C3S+seasonal+multi-system}
#'
#'             Sea Ice Prediction Network (2019). Sea ice prediction network
#'             predictability portal. \url{https://atmos.uw.edu/sipn/.}
"y_month9"


#' Observed September 2006-2007 sea ice concentration
#'
#' The object \code{observed} is the output of the function
#' \code{read_monthly_BS} with \code{start_year = 2006}, \code{end_year = 2007},
#' and \code{version = 3.1}.
#' This array gives the observed sea ice concentrations with dimension
#'  year by month by longitude by latitude.
##' The array is based on observations provided by the National
#'  Aeronautics and Space
#'  Administration (NASA) satellites Nimbus-7 SMMR and DMSP SSM/I-SSMIS and
#'  processed by the Bootstrap algorithm. The results are distributed by the
#'  National Snow and Ice Data Center (Comiso 2017).
#' @docType data
#' @format array of dimension of 2 x 12 x 304 x 448 (year x month x longitude
#' x latitude)
#' @keywords datasets
#' @references Comiso, J., 2017: Bootstrap sea ice concentrations
#'             from Nimbus-7 SMMR and DMSP SSM/I-SSMIS. version 3.
#'             {Boulder, Colorado USA: NASA National Snow and Ice Data Center
#'             Distributed Active Archive Center} doi: \url{https://doi.org/10.5067/7Q8HCCWS4I0R}
#' @usage
#' data(obsSep2006_2007)
"obsSep2006_2007"

#' Observed September 2008 Sea Ice Concentration
#'
#' The object \code{observed} is an binary matrix of dimension longitude by latitude that
#' indicates whether sea ice concentration was at least 15 percent in September 2008.
#' This matrix is based on observations provided by the National
#'  Aeronautics and Space
#'  Administration (NASA) satellites Nimbus-7 SMMR and DMSP SSM/I-SSMIS and
#'  processed by the Bootstrap algorithm. The results are distributed by the
#'  National Snow and Ice Data Center (Comiso 2017).
#' @docType data
#' @format array of dimension of 2 years x 12 months x longitude x latitude
#' @keywords datasets
#' @references Comiso, J., 2017: Bootstrap sea ice concentrations
#'             from Nimbus-7 SMMR and DMSP SSM/I-SSMIS. version 3.
#'             Boulder, Colorado USA: NASA National Snow and Ice Data Center
#'             Distributed Active Archive Center.
#'             doi: \url{https://doi.org/10.5067/7Q8HCCWS4I0R}
#' @usage
#' data(obsSep2008)
"obsSep2008"

#' Predicted September 2006-2007 sea ice probability
#'
#' The object \code{sipSep2006_2007} is an array giving the proportion of ensemble
#' members in the European Center for Medium-Range Weather Forecasts (ECMWF)
#' ensemble that have sea ice concentrations of at least 15 percent.
#' Predictions are made at
#' a lead time of 2.5-month and are  converted to a Polar Stereographic
#' grid. This model output is available from
#' the Sea Ice Prediction Network Predictability Portal or the Copernicus
#' Climate Change Service data store.
#'
#' @docType data
#' @format array of dimension of 2 x 304 x 448 (corresponding to year x
#'         longitude x latitude)
#' @keywords datasets
#' @references Comiso, J., 2017: Bootstrap sea ice concentrations
#'             from Nimbus-7 SMMR and DMSP SSM/I-SSMIS. version 3.
#'             Boulder, Colorado USA: NASA National Snow and Ice Data Center
#'             Distributed Active Archive Center.
#'             doi: \url{https://doi.org/10.5067/7Q8HCCWS4I0R}
#'
#'             Copernicus Climate Change Service (2019). Description of the c3s
#'             seasonal multi-system. \url{https://confluence.ecmwf.int/display/CKB/Description+of+the+C3S+seasonal+multi-system}
#'
#'             Sea Ice Prediction Network (2019). Sea ice prediction network
#'             predictability portal. \url{https://atmos.uw.edu/sipn/.}
#' @usage
#' data(sipSep2006_2007)
"sipSep2006_2007"


#' Predicted September 2008 sea ice probability
#'
#' The object \code{sipSep2008} is a matrix giving the proportion of ensemble
#' members in the European Center for Medium-Range Weather Forecasts (ECMWF)
#' ensemble that have sea ice concentrations of at least 15 percent.
#' Predictions are made at
#' a lead time of 2.5-month and are  converted to a Polar Stereographic
#' grid. This model output is available from
#' the Sea Ice Prediction Network Predictability Portal or the Copernicus
#' Climate Change Service data store.
#' @docType data
#' @format matrix of dimension 304 x 448 (longitude x latitude)
#' @references
#'             Copernicus Climate Change Service (2019). Description of the c3s
#'             seasonal multi-system.\url{https://confluence.ecmwf.int/display/CKB/Description+of+the+C3S+seasonal+multi-system}
#'
#'             Sea Ice Prediction Network (2019). Sea ice prediction network
#'             predictability portal. \url{https://atmos.uw.edu/sipn/.}
#' @keywords datasets
#' @usage
#' data(sipSep2008)
"sipSep2008"

#' Binary predictions September 1993-2018
#'
#' Binary sea ice predictions from the European Center for Medium-Range Weather
#' Forecasts (ECMWF) ensemble for September 1993-2018. A grid box is considered
#' to have sea ice if at least half of the ensemble members have sea ice
#' concentrations of at least 15 percent. Predictions are made at a lead time of
#' 2.5-month and are  converted to a Polar Stereographic grid. This model output
#' is available from the Sea Ice Prediction Network Predictability Portal or the
#' Copernicus Climate Change Service data store.
#' @docType data
#' @format array of dimension of 26 x 304 x 448 (corresponding to year by
#'         longitude by latitude)
#' @keywords datasets
#' @references Copernicus Climate Change Service (2019). Description of the c3s
#'             seasonal multi-system.
#'             \url{https://confluence.ecmwf.int/display/CKB/Description+of+the+C3S+seasonal+multi-system}
#'
#'             Sea Ice Prediction Network (2019). Sea ice prediction network
#'             predictability portal. \url{https://atmos.uw.edu/sipn/.}
#' @examples
#' data(ecmwf_bin)
"ecmwf_bin"

#' Self-intersected polygon
#'
#' Example of a \code{SpatialPolygons} object with a boundary line that contains self-intersections.
#' The object is used to
#' demonstrate the functions that correct self-intersections.
#' @docType data
#' @format n x 2 matrix of coordinates
#' @keywords datasets
#' @examples
#' data(interEx)
#' plot(interEx)
"interEx"

#' Coordinates of an observed line segment
#'
#' Example of the coordinates for an observed line segment used to
#' demonstrate the \code{intLine} function.
#' @docType data
#' @format n x 2 matrix of coordinates
#' @keywords datasets
#' @examples
#' data(obsLEx)
#' head(obsLEx)
"obsLEx"

#' Coordinates of a predicted line segment
#'
#' Example of the coordinates for a predicted line segment used to
#' demonstrate the \code{intLine} function.
#' @docType data
#' @format n x 2 matrix of coordinates
#' @keywords datasets
#' @examples
#' data(predLEx)
#' head(predLEx)
"predLEx"

#' Coordinates of a self-intersected line segment
#'
#' Coordinates of a line segment with self-intersections used to
#' to demonstrate the \code{untwistSec} function.
#' @docType data
#' @format n x 2 matrix of coordiantes
#' @keywords datasets
#' @examples
#' data(currSecEx)
#' head(currSecEx)
"currSecEx"

#' Binary matrix indicating land
#'
#' Binary matrix of dimension 304 by 448 with value 1 for land and
#' 0 otherwise. Data are on a Polar Stereographic grid with the land mask
#' simplified to match model output from the CM2.5 Forecast-oriented Low-Ocean
#' Resolution (FLOR) model. This model output is produced by the National Oceanic and Atmospheric
#' Administration’s Geophysical Fluid Dynamics Laboratory  and converted to a Polar
#' Stereographic grid (Vecchi et al. 2014; Msadek et al. 2014).
#' Weights for converting to a Polar Stereograhic grid were obtained
#' from the spherical coordinate remapping and interpolation package.
#'(SCRIP) (Jones 1997).
#' @docType data
#' @format 304 x 448 matix
#' @keywords datasets
#' @references Vecchi, Gabriel A., et al.
#'             \href{http://journals.ametsoc.org/doi/abs/10.1175/JCLI-D-14-00158.1}{"On the seasonal forecasting of regional tropical} cyclone activity."
#'             Journal of Climate 27.21 (2014): 7994-8016.
#'
#'             Msadek, R., et al.
#'             \href{http://onlinelibrary.wiley.com/doi/10.1002/2014GL060799/full}{"Importance of initial conditionsin seasonal predictions of Arctic sea ice extent."}
#'             Geophysical Research Letters 41.14 (2014): 5208-5215.
#'
#'             National Center for Atmospheric Research, 2017: Earth system grid
#'             at NCAR. \url{https://www.earthsystemgrid.org/home.html}.
#' @examples
#' data(land_mat)
#' image(land_mat, xaxt = "n", yaxt = "n")
"land_mat"


#' Sample parameter information for generating a contour
#'
#' Example list with two elements, \code{mu_est} and \code{sigma_est}, which
#' give the mean and covariance from which an example contour can be generated
#'
#' @docType data
#' @keywords datasets
#' @usage data(pars_1)
"pars_1"

#' Sample list of contours
#'
#' Example list of ten contours in the form of \code{SpatialPolygons} objects
#'
#' @docType data
#' @keywords datasets
#' @usage data(merged)
"merged"


#' Sample collection of completely ice-filled regions
#'
#' Example of a collection of several completely ice-filled regions stored
#' as a single \code{SpatialPolygons} object
#' @docType data
#' @keywords datasets
#' @usage data(full)
"full"

#' Observed sea ice for September 2008
#'
#' September 2008 sea ice edge as \code{SpatialPolygons} object.
#' Computed from the NASA Boostrap sea ice concentration product (Comiso 2017).
#' Grid boxes with sea ice concentration of at least 15 percent are considered to
#' be ice-covered.
#'
#' @docType data
#' @format \code{SpatialPolygons} object
#' @keywords datasets
#' @references Comiso, J., 2017: Bootstrap sea ice concentrations
#'             from Nimbus-7 SMMR and DMSP SSM/I-SSMIS. version 3.
#'             Boulder, Colorado USA: NASA National Snow and Ice Data Center
#'             Distributed Active Archive Center.
#'             doi: \url{https://doi.org/10.5067/7Q8HCCWS4I0R}
#' @usage data(obs_9_2008_poly)
"obs_9_2008_poly"

#' Observed sea ice for September 2005-2007
#'
#' Array of dimension year x longitude by latitude. Binary indicate of whether
#' sea ice concentration of at least 15 percent was observed. Computed from NASA
#' Boostrap sea ice concentration product (Comiso 2017).
#'
#' @docType data
#' @format array
#' @keywords datasets
#' @references Comiso, J., 2017: Bootstrap sea ice concentrations
#'             from Nimbus-7 SMMR and DMSP SSM/I-SSMIS. version 3.
#'             Boulder, Colorado USA: NASA National Snow and Ice Data Center
#'             Distributed Active Archive Center.
#'             doi: \url{https://doi.org/10.5067/7Q8HCCWS4I0R}
#' @usage data(obs_9_2005_2007)
"obs_9_2005_2007"

#' Contour forecast for 2005-2007
#'
#' Array of dimension year by longitude by latitude that gives an example
#' contour forecast for September 2008 at a 1.5-month lead time.
#' The forecast is on a Polar stereographic grid.
#'
#' @docType data
#' @format array
#' @keywords datasets
#' @usage data(cont_9_2005_2007)
"cont_9_2005_2007"

#' Contour forecast for 2008
#'
#' Array of dimension  longitude by latitude that gives an example
#' contour forecast for September 2008 at a 1.5-month lead time.
#' The forecast is on a Polar stereographic grid.
#'
#' @docType data
#' @format array
#' @keywords datasets
#' @usage data(cont_9_2008)
"cont_9_2008"


#' Climatology forecast for 2005-2007.
#'
#' Proportion of times in the preceding ten years that sea ice concentration of
#' at least 15 percent was observed in each  grid box. Array of dimension year by
#' longitude by latitude. Computed from NASA Boostrap sea ice concentration
#' product.
#'
#' @docType data
#' @format array
#' @keywords datasets
#' @usage data(clim_9_2005_2007)
#' @references Comiso, J., 2017: Bootstrap sea ice concentrations
#'             from Nimbus-7 SMMR and DMSP SSM/I-SSMIS. version 3.
#'             Boulder, Colorado USA: NASA National Snow and Ice Data Center
#'             Distributed Active Archive Center.
#'             doi: \url{https://doi.org/10.5067/7Q8HCCWS4I0R}
"clim_9_2005_2007"

#' Climatology forecast for 2008.
#'
#' Proportion of times in the preceding ten years that sea ice concentration of
#' at least 15 percent  was observed in each  grid box. Array of dimension year by
#' longitude by latitude. Computed from NASA Boostrap sea ice concentration
#' product.
#'
#' @docType data
#' @format array
#' @keywords datasets
#' @usage data(clim_9_2008)
#' @references Comiso, J., 2017: Bootstrap sea ice concentrations
#'             from Nimbus-7 SMMR and DMSP SSM/I-SSMIS. version 3.
#'             Boulder, Colorado USA: NASA National Snow and Ice Data Center
#'             Distributed Active Archive Center.
#'             doi: \url{https://doi.org/10.5067/7Q8HCCWS4I0R}
"clim_9_2008"


#' Proportion of total area by grid box
#'
#' Matrix of dimension longitude by latitude. Elements give the proportion of
#' the total area (within the seas of the Arctic) in each grid box. The sum
#' of all elements is 1.
#'
#' @docType data
#' @format array
#' @keywords datasets
#' @usage data(prop_area)
"prop_area"
