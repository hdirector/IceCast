#' Apply contour-shifting to bias correct a predicted contour
#' using computed line lengths
#' @title Apply contour-shifting for bias correction
#' @param y object obtained from the \code{find_y} function
#'          (see details)
#' @param predicted array of predicted sea ice concentrations with dimension
#'                  number of training years x longitude x latitude. The
#'                  number of training years should match \code{n_train_years}
#'                  \code{bc_year}
#' @param bc_year year to be bias-corrected
#' @param pred_start_year year in which prediction array starts
#' @param reg_info  a \code{reg_info} list (see documentation for \code{reg_info})
#' @param level sea ice concentration level for which to build contour
#' @param dat_type_pred string indicating the format of the prediction: either
#'                      "gfdl" or "simple" (see details)
#' @param n_train_years number of years prior to the current year used in fitting
#'                      the bias correction
#' @return \code{SpatialPolygons} object of the adjusted region
#' @export
#' @details The input \code{y} is the output of the \code{find_y} function. It is
#'          composed of a list of four objects where
#'          \code{start_year} and \code{end_year} give the
#'          first year and last year that were evaluated. The variables
#'          \code{obs} and \code{pred} are lists of lists containing the
#'          lengths of each line segment in each year in observations and
#'          predictions respectively. The data are organized so
#'          that the first list index corresponds to the region number and the
#'          second list index corresponds to the year. For each region and year
#'          pair, the vector of line segment lengths are ordered the same as in
#'          \code{reg_info$lines}.

#'          The predicted data array, \code{predicted}, should be a single array
#'          of dimension: years x longitude (304) x latitude (448). If
#'          \code{dat_type_pred = "simple"}, the values in the array should
#'          indicate whether each grid box is categorized as containing ice
#'          where 1 indicates ice-covered, 0 indicates open water, and
#'          NA indicates land. If \code{dat_type_pred = "gfdl"} the
#'          values in the \code{predicted} array must correspond to the ice
#'          concentration values predicted in the CM2.5 Forecast-oriented
#'          Low-Ocean Resolution (FLOR) model produced by the National Oceanic
#'          and Atmospheric Administration’s Geophysical Fluid Dynamics
#'          Laboratory and converted to a Polar Stereographic grid
#'          (Vecchi et al. 2014; Msadek et al. 2014). The data must be formatted
#'          exactly the same including indicators for missing
#'          data, land etc. Weights for converting to
#'          a polar stereograhic grid are obtained from the spherical
#'          coordinate remapping and interpolation package (SCRIP) (Jones 1997).
#' @references
#'
#' Jones, P.W. "A user’s guide for SCRIP: A spherical coordinate remapping
#'  and interpolation package." Los Alamos National Laboratory, Los Alamos, NM (1997).
#'
#' Msadek, R., et al.
#' \href{http://onlinelibrary.wiley.com/doi/10.1002/2014GL060799/full}{"Importance of initial conditions in seasonal predictions of Arctic sea ice extent."}
#'  Geophysical Research Letters 41.14 (2014): 5208-5215.
#'
#' Vecchi, Gabriel A., et al.
#' \href{http://journals.ametsoc.org/doi/abs/10.1175/JCLI-D-14-00158.1}{"On the seasonal forecasting of regional tropical
#' cyclone activity."} Journal of Climate 27.21 (2014): 7994-8016.
#'
#' @importFrom raster aggregate
#' @importFrom sp disaggregate Polygon
#' @importFrom rgeos gArea
#' @importFrom MASS rlm
#' @importFrom stats predict
contour_shift <- function(y, predicted, bc_year, pred_start_year, reg_info,
                          level, dat_type_pred, n_train_years = NULL) {

  ##Read-in and format prediction
  raw <- get_region(dat = predicted, dat_type = dat_type_pred, level)

  #focus is on contour boundary, so ensure land holes are consistent with land mask
  raw <- rm_holes(raw)
  raw <- keep_poly(gDifference(raw, land))

  #indices of data to use
  if (is.null(n_train_years)) {
    train_ind <- (1:(bc_year - y$start_year))
  } else {
    train_ind <- ((bc_year - y$start_year - n_train_years  + 1):(bc_year - y$start_year))
  }

  #Use Central Arctic to check for years with all missing data
  missing <- rep(FALSE, length(train_ind))
  for (i in train_ind) {
    if (is.null(y$y_obs[[i]][[1]])){
      missing[i] <- TRUE
    }
  }
  if (length(missing) > 0) {
    train_ind <- train_ind[-missing]
  }

  #corresponding years to use
  if (is.null(n_train_years)) {
    year_ind <- y$start_year:(bc_year - 1)
  } else {
    year_ind <- (bc_year -n_train_years):(bc_year - 1)
  }
  if (length(missing) > 0) {
    year_ind <- year_ind[-missing]
  }
  n_reg <- length(reg_info$regions)

  ##find length on ice for raw prediction
  y_raw <- find_y_1(ice = raw, reg_info)

  end <- list()
  ##Adjust each region
  for (r in 1:n_reg) {
    angs_r <- reg_info$angs[[r]]
    n_lines_r <- length(reg_info$lines[[r]])
    start_coords_r <- reg_info$start_coords[[r]]
    raw_r <- y$pred[[r]]
    ##adjust Central Arctic region
    end_r <- matrix(ncol = 2, nrow = n_lines_r)
    adj_prop_r <- rep(NA, n_lines_r)
    for (s in 1:n_lines_r) {
      #regressions
      raw_r_s <- sapply(y$pred[[r]], function(x){x[s]})[train_ind]
      lm_raw <- suppressWarnings(rlm(raw_r_s ~ year_ind))
      raw_pred <- predict(lm_raw, newdata = data.frame(year_ind = bc_year))
      obs_r_s <- sapply(y$obs[[r]], function(x){x[s]})[train_ind]
      lm_obs <- suppressWarnings(rlm(obs_r_s ~ year_ind))
      obs_pred <- predict(lm_obs, newdata = data.frame(year_ind = bc_year))

      #calculate new length of mapping vectors
      adj_length <- y_raw[[r]][s] + (obs_pred - raw_pred)

      #add back land sections
      adj_prop_r[s] <- (adj_length/reg_info$max_length[[r]][[s]])
    }
    adj_prop_r[adj_prop_r >= 1] <- 1 #possible to get proportions greater than 1 because of correction

    adj_length_r <- prop_to_y(prop = adj_prop_r, r, reg_info)
    #new x and y coordinates
    end_r[,1] <- start_coords_r[,1] + adj_length_r*cos(angs_r)
    end_r[,2] <- start_coords_r[,2] + adj_length_r*sin(angs_r)
    end[[r]] <- end_r
  }

  ##make polygon for central Arctic region
  adj <- make_polygons(r = 1, my_end = end[[1]], poly_name = "new1")

  ##make adjusted polygons for all other regions
  for (r in 2:n_reg) {
    new <- make_polygons(r, my_end = end[[r]], poly_name = sprintf("new%i", r))
    if (!is.null(new)) {
      adj <- raster::aggregate(spRbind(adj, new))
      adj@polygons[[1]]@ID <- "new"
    }
  }

  #Add back ice islands
  raw <- disaggregate(raw)
  for (r in 1:n_reg) {
    ice_curr <- keep_poly(gIntersection(raw, reg_info$regions[[r]]))
    if (!is.null(ice_curr)) {
      ice_curr <- disaggregate(ice_curr)
      isl <- ice_curr[!gIntersects(ice_curr, reg_info$start_lines[[r]], byid = T)]
      if (!is.null(isl)) {
        spRbind(adj, isl)
      }
    }
  }

  return(adj)
}
