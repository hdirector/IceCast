#' Find length ice extends
#'
#' Find line segment lengths, \eqn{y}, representing how far the ice extends in
#' various fixed directions for a single observations or prediction.
#' The fixed directions are the directions of \code{reg_info$lines} extending
#' outward from the starting point.
#'
#' @return This function returns lists containing the lengths of each line segment
#'         representing how far the sea ice extends in the observation or
#'         prediction. The data are organized so that the first list index
#'         corresponds to the region number. For each region the line segment
#'         lengths are ordered the same as in \code{reg_info$lines}.
#' @param ice \code{SpatialPolygons} object corresponding to the region of ice
#' @param reg_info  \code{reg_info} list (see \code{reg_info} documentation)
#' @importFrom sp SpatialPoints disaggregate
#' @importFrom rgeos gIntersection gLength
#' @export
find_y_1 <- function(ice, reg_info) {
  ##cycle through regions and get their lengths
  n_reg <- length(reg_info$regions)
  map_list <- list()
  y <- list()
  for (r in 1:n_reg) {
    ice_r <- keep_poly(gIntersection(ice, reg_info$regions[[r]]))
    n_lines_r <- length(reg_info$lines[[r]])
    if (!is.null(ice_r)) {
      ice_r <- disaggregate(keep_poly(ice_r))
      if (r != 1) {
        #find intersection of ice with start_lines
        inter_test <- gIntersects(ice_r, reg_info$start_lines[[r]], byid = T)
        if (any(inter_test)) {
          ice_r <- ice_r[inter_test]
        } else {
          ice_r <- NULL
        }
        #find main ice area
      } else {
        ice_r <- ice_r[which.max(gArea(ice_r, byid = T))]
      }
    }

    #get lengths of ice extends on each line y
    if (!is.null(ice_r)) {
      inter <- sapply(reg_info$lines[[r]], function(x){gIntersection(x, ice_r)})
      y[[r]] <- sapply(inter,function(x){
                        if (!is.null(x)) {return(gLength(x))}
                        else {return(0)}})
    } else {
      y[[r]] <- rep(0, length(reg_info$lines[[r]]))
    }
  }
  return(y)
}



#' Find line segment lengths, \eqn{y}, representing how far the ice extends in
#' various fixed directions for a set of observations and predictions over multiple years.
#' The fixed directions are the directions of \code{reg_info$lines} extending
#' outward from the starting point.
#' @title Find length ice extends for a set of predictions
#' @param start_year first year to evaluate
#' @param end_year last year to evaluate
#' @param obs_start_year year in which observation array starts
#' @param pred_start_year year in which prediction array starts
#' @param observed array of observed values of dimension year x longitude x
#'                 latitude
#' @param predicted array of predicted values of dimension year x longitude x
#'                  latitude
#' @param reg_info a \code{reg_info} list (see documentation for \code{reg_info})
#' @param month month under consideration
#' @param level concentration level for which to build contour
#' @param dat_type_obs string of either "bootstrap" or "simple" indicating the
#'                   file type of the observation (see details)
#' @param dat_type_pred string of either "gfdl" or "simple" indicating the file
#'                   type of the prediction (see details)
#' @param obs_only indicator to find \eqn{y} only for observations
#' @param pred_only indicator to find \eqn{y} only for predictions
#' @importFrom sp disaggregate
#' @importFrom rgeos gArea gIntersection
#' @importFrom methods as
#' @importFrom graphics lines
#' @return This function returns a list of four objects where
#'          \code{start_year} and \code{end_year} give the
#'          first year and last year that were evaluated. The variables
#'          \code{obs} and \code{pred} are lists of lists containing the
#'          lengths of each line segment in each year in observations and
#'          predictions respectively. The data are organized so
#'          that the first list index corresponds to the region number and the
#'          second list index corresponds to the year. For each region and year
#'          pair, the vector of line segment lengths are ordered the same as in
#'          \code{reg_info$lines}.
#'
#' @details The predicted data array, \code{predicted}, should be a single array
#'          of dimension: years x longitude (304) x latitude (448). If
#'          \code{dat_type_pred = "simple"}, the values in the array should
#'          indicate whether each grid box is categorized as containing ice
#'          where 1 indicates ice-covered, 0 indicates open water, and
#'          NA indicates land. If \code{dat_type_pred = "gfdl"} the
#'          values in the \code{predicted} array must correspond to the ice
#'          concentration values predicted in the CM2.5 Forecast-oriented
#'          Low-Ocean Resolution (FLOR) model produced by the National Oceanic
#'          and Atmospheric Administration’s Geophysical Fluid Dynamics
#'          Laboratory and converted to a Polar Stereographic grid
#'          (Vecchi et al. 2014; Msadek et al. 2014). The data must be formatted
#'          exactly the same including indicators for missing
#'          data, land etc. Weights for converting to
#'          a polar stereograhic grid are obtained from the spherical
#'          coordinate remapping and interpolation package (SCRIP) (Jones 1997).
#'
#'          The observed data array, \code{observed}, should be a single array
#'          of dimension: years x longitude (304) x latitude (448).
#'          For \code{dat_type_obs = "simple"}  the values in the  matrix
#'          are indicators of whether the grid box contains ice. The value 1
#'          indicates ice-covered, the value 0 indicates not ice-covered,
#'          and the value NA indicates land.  If
#'          \code{datType = "bootstrap"} the array values are formatted the same
#'          as the ice concentration values obtained from the  National
#'          Aeronautics and Space Administration (NASA) satellites Nimbus-7
#'          SMMR and DMSP SSM/I-SSMIS and processed by the bootstrap algorithm.
#'
#' @references
#'
#' Comiso, J., 2017: Bootstrap sea ice concentrations
#'             from Nimbus-7 SMMR and DMSP SSM/I-SSMIS. version 3.
#'             {Boulder, Colorado USA: NASA National Snow and Ice Data Center
#'             Distributed Active Archive Center.}
#'
#' Jones, P.W. "A user’s guide for SCRIP: A spherical coordinate remapping
#'  and interpolation package." Los Alamos National Laboratory, Los Alamos, NM (1997).
#'
#' Msadek, R., et al.
#' \href{http://onlinelibrary.wiley.com/doi/10.1002/2014GL060799/full}{"Importance of initial conditions in seasonal predictions of Arctic sea ice extent."}
#'  Geophysical Research Letters 41.14 (2014): 5208-5215.
#'
#' Vecchi, Gabriel A., et al.
#' \href{http://journals.ametsoc.org/doi/abs/10.1175/JCLI-D-14-00158.1}{"On the seasonal forecasting of regional tropical
#' cyclone activity."} Journal of Climate 27.21 (2014): 7994-8016.
#'
#' @export
find_y <- function(start_year, end_year, obs_start_year, pred_start_year,
                   observed, predicted, reg_info, month, level,
                   dat_type_obs, dat_type_pred,
                   obs_only = FALSE, pred_only = FALSE) {
  n_reg <- length(reg_info$regions)
  n_years <- length(start_year:end_year)
  n_lines <- sapply(reg_info$lines, length)

  #years of interest
  years <- start_year:end_year
  if (!pred_only) {
    missing <- which(apply(observed, 1, function(x){all(is.na(x))}))
    if (length(missing) > 0) {
      years <- years[-missing]
    }
  }

  y_obs_by_year <- list()
  y_pred_by_year <- list()
  ##store mappings for all years
  for (i in years) {
    #read-in and format observation and prediction
    if (!pred_only) {
      obs <- get_region(dat = observed[i - obs_start_year + 1, ,],
                        dat_type = dat_type_obs, level = level)
      #focus is on contour boundary, so ensure land holes are consistent with land mask
      obs <- rm_holes(obs)
      obs <- keep_poly(gDifference(obs, land))
      y_obs_by_year[[i - start_year + 1]] <- find_y_1(ice = obs, reg_info)
    }
    if (!obs_only) {
      pred <- get_region(dat = predicted[i - pred_start_year + 1, ,],
                         dat_type = dat_type_pred, level = level)
      #focus is on contour boundary, so ensure land holes are consistent with land mask
      pred <- rm_holes(pred)
      pred <- keep_poly(gDifference(pred, land))
      y_pred_by_year[[i - start_year + 1]] <- find_y_1(ice = pred, reg_info)
    }
  }



  #re-organize data to be organized in lists by regions rather than by month
  if (!pred_only) {
    y_obs <- list()
    for (r in 1:n_reg) {
      y_obs_r <- list()
      for (i in 1:n_years) {
        y_obs_r[[i]] <- y_obs_by_year[[i]][[r]]
      }
      y_obs[[r]] <- y_obs_r
    }
  }


  if (!obs_only) {
    y_pred <- list()
    for (r in 1:n_reg) {
      y_pred_r <- list()
      for (i in 1:n_years) {
        y_pred_r[[i]] <- y_pred_by_year[[i]][[r]]
      }
      y_pred[[r]] <- y_pred_r
    }
  }


  if (obs_only) {
    y_pred <- NULL
  }
  if (pred_only) {
    y_obs <- NULL
  }


  return(list("start_year" = start_year, "end_year" = end_year,
              "obs" = y_obs, "pred" = y_pred))
}


#' The function evenly spaces the number of points that are on one line,
#' \code{pred_l}, on a different line, \code{obs_l}
#' @title Space points along a line
#' @param pred_l predicted line (n1 x 2 matrix of coordinates)
#' @param obs_l predicted line (n2 x 2 matrix of coordinates)
#' @param plotting boolean indicating whether maps should be plotted
#' @return n x 2 matrix of evenly-spaced coordinates
#' @importFrom graphics plot points
#' @export
#' @examples
#' line_space <- int_line(predLEx, obsLEx, plotting = TRUE)
int_line <- function(pred_l, obs_l, plotting = FALSE) {
  #number of points in prediction and observation
  n_pred <- nrow(pred_l); n_obs <- nrow(obs_l)
  #matrix giving where new points should be mapped to
  map <- matrix(nrow = n_pred, ncol = 2, data = NA)
  colnames(map) <- c("x", "y")

  ##flip indexing of one line if needed
  if (get_dist(obs_l[1, ], pred_l[1, ]) >
      get_dist(obs_l[1, ], pred_l[nrow(pred_l),])) {
    obs_l <- obs_l[nrow(obs_l):1, ]
  }

  ##identify where points on prediction should map onto observation
  #same number of observation as prediction points, just map 1-to-1
  if (n_pred == n_obs) {
    map <- obs_l
  } else  {
    if ((n_obs < n_pred) || (n_pred != 2)) { #typical case
      #assign first and last points to stay matching
      map[1, ] <- pred_l[1,]; map[n_pred,] <- pred_l[n_pred,]
      #proportion of sections of the line used per mapping
      step <- (n_obs - 1)/(n_pred - 1)
      used <- step #keep track of what proportion of the line has been used
      for (i in 2:(n_pred - 1)) {
        #indices of what points the dividing line for each section is between
        s <- floor(used); e  <- ceiling(used)
        #assign mappings,indexing of matrices is off by one from indices of line
        map[i, 1] <- obs_l[s + 1, 1] +
          (used - s)*(obs_l[e + 1, 1] - obs_l[s + 1, 1])
        map[i, 2] <- obs_l[s + 1, 2] +
          (used - s)*(obs_l[e + 1, 2] - obs_l[s + 1, 2])
        used <- used + step #update portion of line used
      }
    } else { #have to be careful when the two
      step <- (n_obs - 1)/3 #proportion of sections of the line used per mapping
      used <- step #set initial proportion used
      for (i in 1:n_pred) {
        #indices of what points the dividing line for each section is between
        s <- floor(used); e  <- ceiling(used)
        #assign mappings,indexing of matrices is off by one from indices of line
        map[i, 1] <- obs_l[s + 1, 1] +
          (used - s)*(obs_l[e + 1, 1] - obs_l[s + 1, 1])
        map[i, 2] <- obs_l[s + 1, 2] +
          (used - s)*(obs_l[e + 1, 2] - obs_l[s + 1, 2])
        used <- used + step #update portion of line used
      }
    }
  }

  ##optional plotting of maps
  if (plotting) {
    plot(pred_l, col = "blue",
         xlim = c(min(c(obs_l[,1], pred_l[,1])), max(c(obs_l[,1], pred_l[,1]))),
         ylim = c(min(c(obs_l[,2], pred_l[,2])), max(c(obs_l[,2], pred_l[,2]))))
    points(pred_l, type = "l", col = "blue")
    points(obs_l, col = "black")
    points(obs_l, col = "black", type = "l")
    points(map, col = "red")
  }
  return(map)
}




